#ifndef _SUM_INTS_H_
#define _SUM_INTS_H_

#include "types.h"

extern node *SInum (node *arg_node, info *arg_info);
extern node *SIdoSumInts( node *syntaxtree);

#endif
